'''
Simple example pokerbot, written in Python.
'''
from skeleton.actions import FoldAction, CallAction, CheckAction, RaiseAction
from skeleton.states import GameState, TerminalState, RoundState
from skeleton.states import NUM_ROUNDS, STARTING_STACK, BIG_BLIND, SMALL_BLIND
from skeleton.bot import Bot
from skeleton.runner import parse_args, run_bot
import random
import eval7

class Player(Bot):
    '''
    A pokerbot.
    '''
    def __init__(self):
        '''
        Called when a new game starts. Called exactly once.
        Arguments:
        Nothing.
        Returns:
        Nothing.
        '''
        self.op_fold_count = 0
        self.opp_all_in_count = 0
        self.win = False
        self.rounds_won = 0
        self.win_round = 0
        self.intimidate_raised = False
        self.intimidate_raise_amount = 400
        self.default_raised = False
        self.default_raise_amount = 400
        self.play_default = False

    def calc_strength(self, hole, iters, community = []):
        '''
        Using MC with iterations to evalute hand strength
        Args:
        hole - our hole carsd
        iters - number of times we run MC
        community - community cards
        '''
        deck = eval7.Deck() # deck of cards
        hole_cards = [eval7.Card(card) for card in hole] # our hole cards in eval7 friendly format

        # If the community cards are not empty, we need to remove them from the deck
        # because we don't want to draw them again in the MC
        if community != []:
            community_cards = [eval7.Card(card) for card in community]
            for card in community_cards: #removing the current community cards from the deck
                deck.cards.remove(card)

        for card in hole_cards: # removing our hole cards from the deck
            deck.cards.remove(card)

        # the score is the number of times we win, tie, or lose
        score = 0

        for _ in range(iters): # MC the probability of winning
            deck.shuffle()

            # Let's see how many community cards we still need to draw
            if len(community) >= 5: # red river case
                # check the last community card to see if it is red
                if community[-1][1] == 'h' or community[-1][1] == 'd':
                    _COMM = 1
                else:
                    _COMM = 0
            else:
                _COMM = 5 - len(community) # number of community cards we need to draw

            _OPP = 2
            draw = deck.peek(_COMM + _OPP)
            opp_hole = draw[:_OPP]
            alt_community = draw[_OPP:] # the community cards that we draw in the MC

            # if there are no community cards, we only need to compare our hand to the opp hand
            if community == []:
                our_hand = hole_cards + alt_community
                opp_hand = opp_hole + alt_community
            else:
                our_hand = hole_cards + community_cards + alt_community
                opp_hand = opp_hole + community_cards + alt_community

            our_hand_value = eval7.evaluate(our_hand)
            opp_hand_value = eval7.evaluate(opp_hand)

            if our_hand_value > opp_hand_value:
                score += 2
            elif our_hand_value == opp_hand_value:
                score += 1
            else:
                score += 0

        hand_strength = score / (2 * iters) # win probability

        return hand_strength

    def handle_new_round(self, game_state, round_state, active):
        '''
        Called when a new round starts. Called NUM_ROUNDS times.
        Arguments:
        game_state: the GameState object.
        round_state: the RoundState object.
        active: your player's index.

        Returns:
        Nothing.
        '''
        my_bankroll = game_state.bankroll # the total number of chips you've gained or lost from the beginning of the game to the start of this round
        game_clock = game_state.game_clock # the total number of seconds your bot has left to play this game
        round_num = game_state.round_num # the round number from 1 to NUM_ROUNDS
        my_cards = round_state.hands[active] # your cards
        big_blind = bool(active) # True if you are the big blind
        round_num = game_state.round_num # the round number from 1 to NUM_ROUNDS
        self.default_raised = False
        self.intimidate_raised = False
        self.play_default = False
        print(f'Round {round_num}')

    def handle_round_over(self, game_state, terminal_state, active):
        '''
        Called when a round ends. Called NUM_ROUNDS times.
        Arguments:
        game_state: the GameState object.
        terminal_state: the TerminalState object.
        active: your player's index.
        Returns:
        Nothing.
        '''
        my_delta = terminal_state.deltas[active] # your bankroll change from this round
        previous_state = terminal_state.previous_state # RoundState before payoffs
        street = previous_state.street # 0, 3, 4, or 5 representing when this round ended
        my_cards = previous_state.hands[active] # your cards
        opp_cards = previous_state.hands[1-active] # opponent's cards or [] if not revealed
        round_num = game_state.round_num # the round number from 1 to NUM_ROUNDS
        my_pip = previous_state.pips[active] # the number of chips you have contributed to the pot this round of betting
        opp_pip = previous_state.pips[1-active] # the number of chips your opponent has contributed to the pot this round of betting

        # if opponent folded
        if my_pip > opp_pip:
            if not self.intimidate_raised or self.intimidate_raise_amount == 2:
                self.op_fold_count += 1

            # if i raised default
            if self.default_raised:
                old = self.default_raise_amount
                self.default_raise_amount = max(int(self.default_raise_amount / 2), 2)
                new = self.default_raise_amount
                print(f'Default: lowering raise from {old} to {new}')

            # if i raised to intimidate
            if self.default_raised or self.intimidate_raised:
                old = self.intimidate_raise_amount
                self.intimidate_raise_amount = max(int(self.intimidate_raise_amount / 2), 2)
                new = self.intimidate_raise_amount
                print(f'Intimidate: lowering raise from {old} to {new}')

        if self.win and self.win_round != 0:
            winrate = self.rounds_won / round_num * 100
            print(f'\nWinrate: {winrate}%')
            self.win = False

        if my_delta >= 0:
            self.rounds_won += 1
            print('Won/Tied')
        else:
            print('Lost')

        print()

    def get_action(self, game_state, round_state, active):
        '''
        Where the magic happens - your code should implement this function.
        Called any time the engine needs an action from your bot.
        Arguments:
        game_state: the GameState object.
        round_state: the RoundState object.
        active: your player's index.
        Returns:
        Your action.
        '''
        my_bankroll = game_state.bankroll # the total number of chips you've gained or lost from the beginning of the game to the start of this round
        legal_actions = round_state.legal_actions() # the actions you are allowed to take
        street = round_state.street # 0, 3, 4, or 5 representing pre-flop, flop, turn, or river respectively
        my_cards = round_state.hands[active] # your cards
        board_cards = round_state.deck[:street] # the board cards
        my_pip = round_state.pips[active] # the number of chips you have contributed to the pot this round of betting
        opp_pip = round_state.pips[1-active] # the number of chips your opponent has contributed to the pot this round of betting
        my_stack = round_state.stacks[active] # the number of chips you have remaining
        opp_stack = round_state.stacks[1-active] # the number of chips your opponent has remaining
        continue_cost = opp_pip - my_pip # the number of chips needed to stay in the pot
        my_contribution = STARTING_STACK - my_stack # the number of chips you have contributed to the pot
        opp_contribution = STARTING_STACK - opp_stack # the number of chips your opponent has contributed to the pot
        net_upper_raise_bound = round_state.raise_bounds()
        stacks = [my_stack, opp_stack] # keep track of our stacks
        round_num = game_state.round_num # the round number from 1 to NUM_ROUNDS
        min_raise, max_raise = round_state.raise_bounds() # the smallest and largest numbers of chips for a legal bet/raise
        max_cost = max_raise - my_pip
        min_cost = min_raise - my_pip


        print(f'  {street}')

        # Check-Fold to guarantee win
        if my_bankroll > 1.5 * (1001 - round_num):
            return self.check_fold(round_num, legal_actions)

        # checking if player raised all in already
        if my_pip == 400:
            return CheckAction()

        # Anti-Safe: if opponent folds more than 50% of the time, wary of op raising
        if self.op_fold_count / round_num >= 0.5:
            op_raised = opp_pip > my_pip + 1

            if self.intimidate_raised:
                op_raised_on_int = op_raised
            else:
                op_raised_on_int = False

            return self.anti_safe(op_raised, op_raised_on_int, legal_actions)

        # opponent is possibly bully
        if opp_pip >= 30:
            self.opp_all_in_count += 1

            # Anti-Bully: call when player has good cards, fold otherwise
            if self.opp_all_in_count / round_num > .40 and round_num > 20:
                pot_total = my_contribution + opp_contribution
                return self.anti_bully(pot_total, street, my_cards, board_cards, legal_actions)

            # opponent not bully
            return FoldAction()

        # Intimidate: if they called/raised
        if not self.play_default and self.intimidate_raised:
            old_amount = self.intimidate_raise_amount
            self.intimidate_raise_amount = 400
            new_amount = self.intimidate_raise_amount
            print(f'Intimidate: Backfired - Op Called | changing raise from {old_amount} to {new_amount}')
            self.play_default = True

        if not self.play_default and self.intimidate_raise_amount <= 100:
            if RaiseAction in legal_actions:
                op_raised = opp_pip > my_pip + 1

                if self.intimidate_raised:
                    op_raised_on_int = op_raised
                else:
                    op_raised_on_int = False

                return self.intimidate(op_raised, op_raised_on_int, legal_actions)
            elif opp_pip == 2 and my_pip == 1:
                return CallAction()
            elif CheckAction in legal_actions:
                return CheckAction()
            else:
                return FoldAction()


        # Default
        print('Default')
        pot_total = my_contribution + opp_contribution
        MONTE_CARLO_ITERS = 200

        if street < 3:
            raise_amount = int(my_pip + continue_cost + 0.4 * (pot_total + continue_cost))
            strength = self.calc_strength(my_cards, MONTE_CARLO_ITERS)
        else:
            raise_amount = int(my_pip + continue_cost + 0.75 * (pot_total + continue_cost))
            strength = self.calc_strength(my_cards, MONTE_CARLO_ITERS, board_cards)

        raise_amount = max([min_raise, raise_amount])
        raise_cost = raise_amount - my_pip

        if (RaiseAction in legal_actions and (raise_cost <= my_stack)):
            temp_action = RaiseAction(raise_amount)
        elif (CallAction in legal_actions and (continue_cost <= my_stack)):
            temp_action = CallAction()
        elif CheckAction in legal_actions:
            temp_action = CheckAction()
        else:
            temp_action = FoldAction()

        if continue_cost > 50:
            scary = 0.5
        elif continue_cost > 30:
            scary = 0.4
        elif continue_cost > 12:
            scary = 0.3
        elif continue_cost > 6:
            scary = 0.2
        else:
            scary = 0

        strength = max([0, strength - scary])
        pot_odds = continue_cost / (pot_total + continue_cost)
        print(f'Default: {strength = } | {pot_odds = }')

        if (RaiseAction in legal_actions and street >= 4
        and ((self.default_raise_amount < 50 and strength >= 0.7)
        or (50 <= self.default_raise_amount < 100 and strength >= 0.8)
        or (100 <= self.default_raise_amount and strength >= 0.9))):
            if self.default_raised:
                self.default_raise_amount = min(self.default_raise_amount * 2, 400)

            self.default_raised = True
            default_raise = min(self.default_raise_amount, max_raise)
            print(f'Default: Super confident | {strength = } | {pot_odds = } | raised {default_raise}')
            return RaiseAction(default_raise)

        if strength >= pot_odds:
            print(f'Default: Confident | {strength = } | {pot_odds = }')
            if (temp_action == RaiseAction
            and ((raise_amount < 50 and strength >= 0.5)
            or (50 <= raise_amount < 100 and strength >= 0.6)
            or (100 <= raise_amount and strength >= 0.7))):
                print(f'Default: raised {raise_amount}')
                return temp_action
            elif CallAction in legal_actions:
                print('Default: Called')
                return CallAction()
            else:
                print('Default: Checked')
                return CheckAction()
        elif CheckAction in legal_actions:
            return CheckAction()
        else:
            return FoldAction()

    '''
    Different Strategies
    '''

    def check_fold(self, round_num, legal_actions):
        print('Check Folding')
        if self.win_round == 0:
            self.win_round = round_num
            self.win = True

        if FoldAction in legal_actions:
            return FoldAction()
        else:
            return CheckAction()


    def anti_safe(self, op_raised, op_raised_on_int, legal_actions):
        if op_raised:
            print('Anti-Safe: folding because opponent is confident')
            return FoldAction()
        else:
            print('Anti-Safe: resorting to Intimidate')
            return self.intimidate(op_raised, op_raised_on_int, legal_actions)


    def intimidate(self, op_raised, op_raised_on_int, legal_actions):
        # if opponent didn't raise, keep doing it
        if RaiseAction in legal_actions and not op_raised and not self.intimidate_raised:
            raise_amount = self.intimidate_raise_amount
            print(f'Intimidate: raising by {raise_amount}')
            self.intimidate_raised = True
            return RaiseAction(raise_amount)
        # if opponent raised on intimidate, fold
        elif op_raised_on_int:
            old_amount = self.intimidate_raise_amount
            self.intimidate_raise_amount = 400
            new_amount = self.intimidate_raise_amount
            print(f'Intimidate: Backfired - Op Raised | changing raise from {old_amount} to {new_amount}')
            self.intimidate_raised = False
            return FoldAction()
        # if opponent raised but not on this strat
        else:
            print(f'Intimidate: Op Raised first | folding for caution')
            return FoldAction()


    def anti_bully(self, pot_total, street, my_cards, board_cards, legal_actions):
        MONTE_CARLO_ITERS = 200

        if street < 3:
            strength = self.calc_strength(my_cards, MONTE_CARLO_ITERS)
        else:
            strength = self.calc_strength(my_cards, MONTE_CARLO_ITERS, board_cards)

        if strength >= 0.5:
            if CallAction in legal_actions:
                print('Anti-Bully: Calling')
                return CallAction()
            else:
                return CheckAction()
        else:
            print('Anti-Bully: Folding')
            return FoldAction()


if __name__ == '__main__':
    run_bot(Player(), parse_args())
